﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Room_Management_DavidT
{
    public class Rezervacije
    {
        private int id, userID, pocetakID, krajID, prostorijaID, ponavljanjeID;
        private DateTime datum;
        private bool aktivno;
        public Rezervacije() { }
        public Rezervacije(int i,DateTime d,int u,int poc,int k,int pro,int pon,bool akt)
        {
            this.id = i;
            this.datum = d;
            this.userID = u;
            this.pocetakID = poc;
            this.krajID = k;
            this.prostorijaID = pro;
            this.ponavljanjeID = pon;
            this.aktivno = akt;
        }
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public int UserID
        {
            get { return userID; }
            set { userID = value; }
        }
        public DateTime Datum
        {
            get { return datum; }
            set { datum = value; }
        }
        public bool Aktivno
        {
            get { return aktivno; }
            set { aktivno = value; }
        }
        public int PocetakID
        {
            get { return pocetakID;}
            set { pocetakID = value;}
        }
        public int ProstorijaID
        {
            get { return prostorijaID;}
            set { prostorijaID = value;}
        }
        public int PonavljanjeID
        {
            get { return ponavljanjeID;}
            set { prostorijaID = value;}
        }
        public int KrajID
        {
            get { return krajID;}
            set { krajID = value;}
        }
    }
}
