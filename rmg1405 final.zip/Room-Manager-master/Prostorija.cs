﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Room_Management_DavidT
{
    public class Prostorija
    {
        private int id;
        private string naziv;
        public Prostorija() { }
        public Prostorija(int i,string n)
        {
            this.id = i;
            this.naziv = n;
        }
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public string Naziv
        {
            get { return naziv; }
            set { naziv = value; }
        }
    }
}
