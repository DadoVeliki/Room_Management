﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Room_Management_DavidT
{
    public class UserPrava
    {
        private int id,userID,pravoID;
        public UserPrava() { }
        public UserPrava(int i,int u,int p)
        {
            this.id = i;
            this.userID = u;
            this.pravoID = p;
        }
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        public int PravoID
        {
            get { return pravoID; }
            set { pravoID = value; }
        }
        public int UserID
        {
            get { return userID; }
            set { userID = value; }
        }
    }
}
