﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Room_Management_DavidT
{
    public partial class Pregled : Form
    {
        public Pregled()
        {
            InitializeComponent();
        }
    }
}
