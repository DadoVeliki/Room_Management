﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Room_Management_DavidT
{
    public class Spajanje
    {   public SqlConnection cnn;
        public Spajanje()
        {
            string cs; 
            //cs = @"Data Source=192.168.43.180,51302\SQLEXPRESS;Initial Catalog=room_management;User ID=room_mng;Password=12345";
            cs= @"Data Source=localhost\sqldado;Initial Catalog=room_management;User ID=adminRM;Password=123";
            cnn = new SqlConnection(cs);
            cnn.Open();
            cnn.Close();
        }
        public static Spajanje instance = null;
        public static Spajanje GetInstance()
        {
            if(instance == null)
            {
                instance = new Spajanje();
            }
            return instance;
        }
        
    }
}
