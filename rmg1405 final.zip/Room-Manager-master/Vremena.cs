﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Room_Management_DavidT
{
    public class Vremena
    {
        private int id;
        private TimeSpan pocetak;
        public Vremena() { }
        public Vremena(int i,TimeSpan p)
        {
            this.id = i;
            this.pocetak = p;
        }
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public TimeSpan Pocetak
        {
            get { return pocetak; }
            set { pocetak = value; }
        }
    }
}

